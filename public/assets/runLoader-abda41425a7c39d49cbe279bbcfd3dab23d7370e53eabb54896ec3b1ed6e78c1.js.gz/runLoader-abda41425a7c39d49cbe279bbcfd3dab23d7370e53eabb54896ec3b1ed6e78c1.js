function showLoader() {
    $("#loader").show();
}

;
