def is_better_snack(a_sweetness, a_calories, a_proteins, a_popularity, a_sweetness, b_calories, b_proteins, b_popularity)
    # Complete this method
end

# DO NOT MODIFY ANYTHING BELOW
# DO NOT MODIFY THE METHOD NAME OR PAREMETER NAMES

a_sweetness = (ARGV[0]).to_i
a_calories = (ARGV[1]).to_i
a_proteins = (ARGV[2]).to_i
a_popularity = (ARGV[3]).to_s
b_sweetness = (ARGV[4]).to_i
b_calories = (ARGV[5]).to_i
b_proteins = (ARGV[6]).to_i
b_popularity = (ARGV[7]).to_s

puts "%s\n" % [is_better_snack(a_sweetness, a_calories, a_proteins, a_popularity, b_sweetness, b_calories,  b_proteins,b_popularity)]
