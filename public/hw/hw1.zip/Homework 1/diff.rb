def diff(x, y)
    if # complete the if condition
        return # complete the return value
    else
        return # complete the return value
    end
end

# DO NOT MODIFY ANYTHING BELOW
# DO NOT MODIFY THE METHOD NAME OR PAREMETER NAMES

input_1 = (ARGV[0]).to_i
input_2 = (ARGV[1]).to_i

puts "%d\n" % [diff(input_1, input_2)]
