def leap(n)
    # Complete this Method.
end

# DO NOT MODIFY ANYTHING BELOW
# DO NOT MODIFY THE METHOD NAME OR PAREMETER NAMES

input = (ARGV.first).to_i
puts "%s\n" % [leap(input)]
