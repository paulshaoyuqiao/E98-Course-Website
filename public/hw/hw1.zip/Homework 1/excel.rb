def convert_to_excel(n)
    # Complete the Method
	# Hint 1: Consider splitting your method into 3 separate cases based on the
    # possible number of letters the converted Excel representation can have using
    # the if - elsif - else statements.
    # Hint 2: You are welcome (but not required) to fill in the helper method
    # below or add additional helper methods and use it in this method.
    # The method we have provided below converts a 1-digit column number to the
    # corresponding Excel representation.

    # For example:
    # Column 1 would be mapped to the string “A”.
    # Column 2 would be mapped to the string “B”.
    # Column 26 would be mapped to the string “Z”.
    # Column 27 would be mapped to the string “AB”.
    # Column 28 would be mapped to the string “AC”.
end

def convert_single_digit(n)
    # Complete the Method
    # Note that n is guaranteed to have only 1 digit!
end

# DO NOT MODIFY ANYTHING BELOW
# DO NOT MODIFY THE METHOD NAME OR PAREMETER NAMES

input = (ARGV.first).to_i
puts "%s\n" % [convert_to_excel(input)]
