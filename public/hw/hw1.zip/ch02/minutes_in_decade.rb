# Print out the number of minutes in a decade.
# Make sure to account for leap years here too!


### Your Code Here ###
