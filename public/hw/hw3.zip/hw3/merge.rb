def merge(a, b)
    # Please follow the provided recursive skeleton by filling in the blanks.
    # Recursively merge 2 sorted arrays a and b together into 1 sorted array.
    if _________________________________
        return _________________________________
    elsif _________________________________
        return _________________________________
    else
        return _________________________________
    end
end

# DO NOT MODIFY ANYTHING BELOW
# DO NOT MODIFY THE METHOD NAME OR PAREMETER NAMES

array_1 = (ARGV[0]).split(",")
array_1 = array_1.map(&:to_i)
array_2 = (ARGV[1]).split(",")
array_2 = array_2.map(&:to_i)
merged_array = merge(array_1, array_2)
puts "%s\n" % [merged_array.join('')]
