def merge(a, b)
    # Please follow the provided recursive skeleton by filling in the blanks.
    # Recursively merge 2 sorted arrays a and b together into 1 sorted array.
    if _________________________________
        return _________________________________
    elsif _________________________________
        return _________________________________
    else
        return _________________________________
    end
end
