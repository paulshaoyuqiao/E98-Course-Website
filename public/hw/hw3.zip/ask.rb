# Use `return` to exit from the loop
# Three cases for an answer: yes, no, or anything else