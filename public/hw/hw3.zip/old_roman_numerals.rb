# Hint: use integer division and modulus to decrease the number
# Examples: 299 => CCLXXXXVIIII, 1868 => MDCCCLXVIII, 1494 => MCCCCLXXXXIIII

# Reference: I = 1, V = 5, X = 10, L = 50, C = 100, D = 500, M = 1000


puts('Please call the method with an integer between 1 and 3000.')

def old_roman_numeral(num)

  ### FILL IN WITH YOUR CODE ###

end