def track_collisions(A)
    # Complete the Method Body

    # Takes in an array of integers A encoding the asteroids.
    # Returns an array representing the asteroids remaining after 
    # all the collisions have happened within the tracker's scope.
end

# DO NOT MODIFY ANYTHING BELOW
# DO NOT MODIFY THE METHOD NAME OR PAREMETER NAMES

asteroids = (ARGV[0]).to_i

puts "%d\n" % [track_collisions(asteroids)]