def find_duplicate(file_paths)
    # Complete the Method Body

    # Takes in a list of file paths (strings).
    # Returns a list of group of dupliate file paths.
end

# DO NOT MODIFY ANYTHING BELOW
# DO NOT MODIFY THE METHOD NAME OR PAREMETER NAMES

file_paths = (ARGV[0]).split(',')

puts "%s\n" % [find_duplicate(file_paths)]