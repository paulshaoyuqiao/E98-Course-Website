# Make sure you read the whole tip section, there's some good stuff there!

line_width = # Set it to a default length you'll use throughout
title = "Table of Contents"

# Depending on your solution, you may use more than one array, but here's one to get you started
chapters = [] 

### Your Code Here ###
