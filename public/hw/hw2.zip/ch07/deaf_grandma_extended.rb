puts 'COME GIVE GRANNY A KISS!'

bye_counter = 0
while () # Fill in the while condition
  ### Your Code Here ###
end

puts 'OK SONNY, TALK AGAIN SOON'