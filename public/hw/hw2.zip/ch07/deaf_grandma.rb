puts 'COME GIVE GRANNY A KISS!'

while () # Fill in the while condition
  ### Your Code Here ###
end

puts 'OK SONNY, TALK AGAIN SOON'
