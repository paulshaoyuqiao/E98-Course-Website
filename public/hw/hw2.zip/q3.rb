def add_numbers(x, y, b)
    # Complete the Method Body

    # Takes in 2 arrays representing integers X and Y in base b.
    # Returns an array representing the sum X + Y in base b.
end


# DO NOT MODIFY ANYTHING BELOW
# DO NOT MODIFY THE METHOD NAME OR PAREMETER NAMES

x = (ARGV[0]).split(",")
x = x.map(&:to_i)
y = (ARGV[1]).split(",")
y = y.map(&:to_i)
b = (ARGV[2]).to_i

puts "%s\n" % [add_numbers(x, y, b)]