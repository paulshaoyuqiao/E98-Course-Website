def track_collisions(asteroids)
    # Complete the Method Body

    # Takes in an array of integers A encoding the asteroids.
    # Returns an array representing the asteroids remaining after 
    # all the collisions have happened within the tracker's scope.
end

# DO NOT MODIFY ANYTHING BELOW
# DO NOT MODIFY THE METHOD NAME OR PAREMETER NAMES

asteroids = (ARGV[0]).split(",")
asteroids = asteroids.map(&:to_i)

puts "%s\n" % [track_collisions(asteroids)]