def longest_collatz(x)
    # Complete the Method Body

    # Takes in a positive integer x.
    # Returns the largest positive integer less than x that produces 
    # the longest possible sequence based on the provided iterative rule.
end

# DO NOT MODIFY ANYTHING BELOW
# DO NOT MODIFY THE METHOD NAME OR PAREMETER NAMES

initial_x = (ARGV[0]).to_i

puts "%d\n" % [longest_collatz(initial_x)]